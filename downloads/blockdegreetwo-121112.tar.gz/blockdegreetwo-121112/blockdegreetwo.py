#!/usr/bin/python

# -*- coding: utf-8 -*-

# Authors:
# Patrick Hommers <patrick.hommers@hhu.de>
# Wolfgang Maier <maierw@hhu.de>

# Original Java implementation by
# Miriam Kaeshammer <kaeshammer@phil.hhu.de>
# Wolfgang Maier <maierw@hhu.de>

# Implements the tree transformations for NeGra described in
# Maier et al. (2012) (see <http://www.wolfgang-maier.net>)

# Version November 12, 2012

import sys
import getopt
import os
import codecs


################################################################
#
# TASKS
#
################################################################

class Task(object):

    """ Base class for doing something with a tree """

    def do(self, tree):
        """ Do something with a single tree """

        raise NotImplementedError('Base class')

    def done(self):
        """ Do something after all trees are processed """

        raise NotImplementedError('Base class')


################################################################
#
# UTILITY
#
################################################################

class Progress(Task):

    """ Prints a number depending on the id of the processed tree. """

    def __init__(self, interval):
        self._interval = interval

    def do(self, tree):
        """ Print a number at tree.id % interval """

        if tree.id % self._interval == 0:
            print tree.id

    def done(self):
        """ Do nothing """

        pass


################################################################
#
# TREE RELATED STUFF
#
################################################################

class NodeLabel(object):

    """ Node with a label, a parent, an id and an unordered list of
    children. Node identity is to be checked via the ID, there is no
    __cmp__, i.e., == will use the object reference of a node. """

    def __init__(self):
        self.word = ''
        self.node = ''
        self.edge = ''

    def __str__(self):
        return self.word + ':' + self.node + ':' + self.edge


class Tree(object):

    """ A tree with an ID and a root node. Terminals numbered from
    1..n by convention, Non-terminal IDs must be unique and > n. Nodes
    are kept in a hash by their ID. Note  that it is an error to do
    anything with nodes which have not been added to the hash using
    add_node. Note that it is not guaranteed that all nodes are
    reachable from  the root: Subtrees can be disconnected by removing
    the correponding edges. """

    def __init__(self):
        self.root = 0
        self._data = {}
        self._children = {}
        self._parents = {}
        self._ids = set([])
        self.id = -1

    def __len__(self):
        return len(self._ids)

    def add_node(self, nid, data):
        """ Add a node to the tree defined by id and data """

        if self.exists(nid):
            raise RuntimeError('nid is already present')
        self._ids.add(nid)
        self._data[nid] = data
        self._children[nid] = []
        self._parents[nid] = -1

    def remove_node(self, nid):
        """ Remove a node from the tree by id """

        del self._data[nid]
        del self._children[nid]
        del self._parents[nid]
        self._ids.remove(nid)

    def data(self, nid):
        """ Retrieve the data of a node by id """

        return self._data[nid]

    def exists(self, nid):
        """ Returns True if the node id exists in the tree. """

        return nid in self._ids

    def nodes(self, nid):
        """ Retrieve all node ids of nodes of a subtree depth-first 
        using ordered_children """

        result = [nid]
        for cid in self.ordered_children(nid):
            result += self.nodes(cid)
        return result

    # edges

    def add_edge(self, pid, cid):
        """ Add an edge between two nodes by id. Both nodes must be
        there. """

        self._children[pid].append(cid)
        self._parents[cid] = pid

    def remove_edge(self, pid, cid):
        """ Remove an edge by id. Both nodes and the edge must be
        there. """

        self._children[pid].remove(cid)
        self._parents[cid] = -1

    def exists_edge(self, pid, cid):
        """ Returns True if there is an edge between two nodes (by
        id). """

        return pid in self._children and cid in self._children[pid]

    # children, dominance

    def unordered_children(self, nid):
        """ Get the children of a node by id, without a guaranteed
        order. """

        return list(self._children[nid])

    def ordered_children(self, nid):
        """ Get the children of a node by id, ordered by their
        resp. leftmost terminal descendant. """

        return sorted(self._children[nid], key=self.leftmost_terminal)

    def parent(self, nid):
        """ Get the parent of a node by id. """

        return self._parents[nid]

    def dominating_nodes(self, nid, include_self):
        """ Get all nodes which dominate a given node, maybe the node 
        itself, and 1000 for the root node. """

        result = []
        if not include_self:
            did = self._parents[nid]
            if did == -1:
                return []
        else:
            did = nid
        while not self._parents[did] == -1:
            result.append(did)
            did = self._parents[did]
        result.append(1000)
        return result

    # siblings

    def right_sibling(self, nid):
        """ Get the id of the left sibling of a node, -1 if no sibling
        there """

        # check if nid is root

        if nid == 0:
            return -1
        pid_children = self.ordered_children(self.parent(nid))
        for (i, pid_child) in enumerate(pid_children[:-1]):
            if pid_children[i] == nid:
                return pid_children[i + 1]
        return -1

    # terminals

    def leftmost_terminal(self, nid):
        """ Get the leftmost terminal descendant dominated by a node
        (by id). """

        cids = self.unordered_children(nid)
        if len(cids) == 0:
            return nid
        else:
            return min([self.leftmost_terminal(cid) for cid in cids])

    def terminals(self, nid):
        """ Get all terminals dominated by a node (its yield), by
        id. """

        cids = self.unordered_children(nid)
        if len(cids) == 0:
            return [nid]
        else:
            result = []
            for cid in cids:
                result += self.terminals(cid)
            return sorted(result)

    # yield blocks, discontinuity

    def blocks(self, nid):
        """ Get a two dimensional array with all yield blocks of a
        node (by id). """

        result = []
        block = []
        for tid in self.terminals(nid):
            if len(block) == 0:
                block.append(tid)
            else:
                if not tid - 1 == block[-1]:
                    result.append(block)
                    block = []
                block.append(tid)
        result.append(block)
        return result

    # node numbering

    def compute_export_numbering(self):
        """ Reset IDs such that they confirm to export format
        conventions. NeGra-style,  numbering organized by attachment
        levels. """

        # get non-terminals and terminals

        non_terminal_ids = [nid for nid in self.nodes(self.root)
                            if len(self.unordered_children(nid)) > 0
                            and not nid == 0]

        # sort non-terminals by levels. Between a non-terminal N of level k and any terminal
        # N dominates, there is at least one longest path of k - 1 non-terminals

        levels = {}

        # get non-terminal levels

        for non_terminal_id in non_terminal_ids:
            pathlens = []
            for tid in self.terminals(non_terminal_id):
                path = []
                nid = tid
                while not nid == non_terminal_id and not nid == -1:
                    path.append(nid)
                    nid = self._parents[nid]
                pathlens.append(len(path))

            # level is the maximal path length

            level = max(pathlens)
            if not level in levels:
                levels[level] = []
            levels[level].append(non_terminal_id)

        # now sort all level arrays (lists of nodes in level) by leftmost terminals

        for level in levels:
            levels[level] = sorted(levels[level],
                                   key=self.leftmost_terminal)

        # now from lowest to highest level, continuously distribute numbers
        # on non-terminals. First build map, then build new tree.

        nmap = {}
        cur_id = 500
        for levelnum in sorted(levels.keys()):
            level = levels[levelnum]
            for non_terminal_id in level:
                nmap[non_terminal_id] = cur_id
                cur_id += 1

        # root and terminals don't change

        nmap[0] = 0
        for nid in self.nodes(self.root):
            if len(self.unordered_children(nid)) == 0:
                nmap[nid] = nid
        new_data = {}
        new_children = {}
        new_parents = {}
        new_ids = set([])
        for num in nmap:

            # map data
            # if len(self._children[num]) > 0:
                # self._data[num].word = "#" + str(nmap[num])

            new_data[nmap[num]] = self._data[num]
            if new_data[nmap[num]].word.startswith('#'):
                new_data[nmap[num]].word = '#' + str(nmap[num])

            # map the children

            new_children[nmap[num]] = []
            for cid in self._children[num]:
                new_children[nmap[num]].append(nmap[cid])

            # map the parent if not root (i.e., if has parent)

            if not self._parents[num] == -1:
                new_parents[nmap[num]] = nmap[self._parents[num]]
            elif self._parents[num] == -1:
                new_parents[nmap[num]] = -1

            # add new id

            new_ids.add(nmap[num])
        self._data = new_data
        self._children = new_children
        self._parents = new_parents
        self._ids = new_ids


################################################################
#
# TREE READING
#
################################################################

class ExportTreeReader:

    """ Read trees in export format. """

    @staticmethod
    def parse_export_sentence(tree, has_lemma):
        """ Parse a list of export format lines and return a Tree. """

        result = Tree()

        # get BOS marker

        bos = tree[0]

        # get id

        result.id = int(bos.split()[1])

        # counts the implicitly numbered terminals

        term_cnt = 1

        # collects all parsed nodes (hashed by their number)

        data = {}

        # children/parent of nodes

        children = {}

        # create a root node

        label = NodeLabel()
        label.word = '#0'
        label.node = 'VROOT'
        label.edge = '--'
        data[0] = label

        # loop through all nodes (except BOS/EOS lines)

        for line in tree[1:-1]:
            label = NodeLabel()
            pid = -1
            nid = -1
            split_line = line.strip().split()
            if has_lemma:
                raise NotImplementedError('Supported for lemma field not yet implemented'
                        )
            else:
                label.word = split_line[0]
                label.node = split_line[1]
                label.edge = split_line[3]
                pid = int(split_line[4])
                if line.startswith('#') and len(split_line[0]) == 4 \
                    and (split_line[0])[1:3].isdigit():
                    nid = int((split_line[0])[1:])
                else:
                    nid = term_cnt
                    term_cnt += 1
            if not pid in children:
                children[pid] = []
            children[pid].append(nid)
            data[nid] = label

        # set parents and children fields

        for nid in data:
            result.add_node(nid, data[nid])
        for nid in data:
            if nid in children:
                for cid in children[nid]:
                    result.add_edge(nid, cid)

        # set root node

        result.root = 0
        return result

    def parse(self, stream, tasks):
        """ Parse a series of export format trees """

        in_sentence = False
        sentence = []
        for line in stream:
            if in_sentence:
                sentence.append(line)
                if line.startswith('#EOS'):
                    in_sentence = False
                    tree = \
                        ExportTreeReader.parse_export_sentence(sentence,
                            False)
                    if not tasks == None and not len(tasks) == 0:
                        for task in tasks:
                            task.do(tree)
                    sentence = []
            else:
                if line.startswith('#BOS'):
                    in_sentence = True
                    sentence.append(line)
        if not tasks == None and not len(tasks) == 0:
            for task in tasks:
                task.done()


################################################################
#
# TREE WRITING
#
################################################################

class ExportWriterTask(Task):

    """ Write all trees in export format """

    def __init__(self, stream, consecutive):
        self._output_stream = stream
        self._consecutive = consecutive
        self._cnt = 1

    @property
    def os(self):
        return self._output_stream

    @staticmethod
    def _export_formatted(label, pid):
        """ Return an export-V3 conform string representation of this
        node """

        result = label.word
        tabnum = (24 - len(label.word)) / 8 + 1
        for _ in range(0, tabnum - 1):
            result += '\t'
        result += '\t' + label.node
        result += '\t'

        # morph field not supported yet

        result += '--'
        result += '\t\t\t' + label.edge
        result += '\t\t' + str(pid)

        # no secedge or comments supported either

        return result

    def do(self, tree):
        """ Write a single tree in export format """

        tree.compute_export_numbering()
        if self._consecutive:
            self.os.write('#BOS ' + str(self._cnt) + '\n')
        else:
            self.os.write('#BOS ' + str(tree.id) + '\n')
        terminal_ids = tree.terminals(tree.root)
        for terminal_id in terminal_ids:
            terminal_label = tree.data(terminal_id)
            terminal_pid = tree.parent(terminal_id)
            formatted_terminal = \
                ExportWriterTask._export_formatted(terminal_label,
                    terminal_pid)
            self.os.write(formatted_terminal + '\n')
        for nid in range(500, 500 + len(tree) - len(terminal_ids) - 1):
            node_label = tree.data(nid)
            node_pid = tree.parent(nid)
            formatted_node = \
                ExportWriterTask._export_formatted(node_label, node_pid)
            self.os.write(formatted_node + '\n')
        if self._consecutive:
            self.os.write('#EOS ' + str(self._cnt) + '\n')
            self._cnt += 1
        else:
            self.os.write('#EOS ' + str(tree.id) + '\n')

    def done(self):
        """ Does nothing """

        pass


################################################################
#
# TRANSFORMATIONS
#
################################################################

class T1(Task):

    """ Lower all nodes n attached to root. Comments in the code. """

    def do(self, tree):
        terms = tree.terminals(tree.root)
        min_terminal = min(terms)
        max_terminal = max(terms)

        # iterate through children of root node left to right

        for nid in tree.ordered_children(tree.root):

            # borders of the span

            nid_terms = tree.terminals(nid)
            nid_l = min(nid_terms)
            nid_r = max(nid_terms)

            # if left border == beginning of sentence, proceed to next root child

            if nid_l == min_terminal:
                continue

            # otherwise left neighbor is one left of left border

            left_neighbor = nid_l - 1

            # now on the right, iterate through siblings until we find the first
            # sibling the span of which is not adjacent to the span of the current node

            right_neighbor_ancestor = nid
            right_neighbor_ancestor_terms = \
                tree.terminals(right_neighbor_ancestor)
            right_sib = tree.right_sibling(right_neighbor_ancestor)

            # if there is a sibling get the terminals

            if right_sib != -1:
                right_sib_terms = tree.terminals(right_sib)
            while right_sib != -1 \
                and max(right_neighbor_ancestor_terms) + 1 \
                == min(right_sib_terms):
                right_neighbor_ancestor = right_sib
                right_neighbor_ancestor_terms = \
                    tree.terminals(right_neighbor_ancestor)
                right_sib = tree.right_sibling(right_neighbor_ancestor)

                # if there is a sibling get the terminals

                if right_sib != -1:
                    right_sib_terms = tree.terminals(right_sib)

            # right neighbor is rightmost terminal of last adjacent sibling

            right_neighbor = max(right_neighbor_ancestor_terms) + 1

            # if beyond sentence, proceed to next root child

            if right_neighbor > max_terminal:
                continue
            if tree.exists(left_neighbor) \
                and tree.exists(right_neighbor) and left_neighbor > 0 \
                and right_neighbor < 500:
                left_dominate = tree.dominating_nodes(left_neighbor,
                        False)
                right_dominate = tree.dominating_nodes(right_neighbor,
                        False)
                lca = \
                    min(set(left_dominate).intersection(set(right_dominate)))
                if lca == 1000:
                    lca = 0

                # move only if lca is really a new parent

                if not tree.parent(nid) == lca:

                    # is root

                    pid = tree.parent(nid)
                    tree.remove_edge(pid, nid)

                    # check if the punctuation had its own phrase (should not happen though)
                    # and make sure lone nonterminals are removed

                    to_remove = []
                    while pid != -1 \
                        and len(tree.unordered_children(pid)) == 0:
                        tree.remove_edge(tree.parent(pid), pid)

                        # remember lone non-terminal

                        to_remove.append(pid)
                        pid = tree.parent(pid)

                    # remove all lone non-terminals

                    for lone_nonterminal in to_remove:
                        tree.remove_node(lone_nonterminal)

                    # add an edge from the lca to the former root-attached node

                    tree.add_edge(lca, nid)

    def done(self):
        pass


class T2(Task):

    def __init__(self):
        self.EDGES_UNDER_S = [
            'SB',
            'EP',
            'CP',
            'JU',
            'CM',
            'AC',
            'DM',
            ]
        self.AUX_EDGE_LABEL = 'AUX'
        self.EDGE_LABEL = ['OC', 'HD', 'PD']
        self.countS = 0
        self.countVPUnderS = 0
        self.countNewVPUnderS = 0
        self.countVPErased = 0
        self.allVP = True
        self.countSatz = 0

    def do(self, tree):
        node = 580
        for nid in tree.nodes(tree.root):
            if tree.data(nid).node == 'S':
                self.countS += 1
                vp = None
                va = None
                hd = None
                for cid in tree.ordered_children(nid):
                    if tree.data(cid).node == 'VP' \
                        and tree.data(cid).edge in self.EDGE_LABEL:
                        vp = cid
                    if tree.data(cid).edge == 'HD':
                        hd = cid
                        if tree.data(cid).node.startswith('VA'):
                            va = cid

                if vp != None and va != None:
                    self.countVPUnderS += 1
                    for cid in tree.ordered_children(nid):
                        if cid != vp and tree.data(cid).edge \
                            not in self.EDGES_UNDER_S \
                            and tree.data(cid).edge != 'SB':
                            tree.remove_edge(nid, cid)
                            tree.add_edge(vp, cid)
                    tree.data(va).edge = self.AUX_EDGE_LABEL
                elif self.allVP and hd != None:

                    self.countNewVPUnderS += 1
                    label = NodeLabel()
                    label.word = '#599'
                    label.node = 'VP'
                    label.edge = 'HD'
                    tree.add_node(node, label)
                    vp = node
                    node += 1
                    for cid in tree.ordered_children(nid):
                        if tree.data(cid).edge \
                            not in self.EDGES_UNDER_S:
                            tree.remove_edge(nid, cid)
                            tree.add_edge(vp, cid)
                    tree.add_edge(nid, vp)
        tree.compute_export_numbering()
        self.eraseVAVPs(tree)

    def eraseVAVPs(self, tree):
        to_delete = []
        nodes = []
        for nid in tree.nodes(tree.root):
            if nid > 0:
                nodes.append(nid)
        nodes = sorted(nodes)
        nodes.append(0)
        for node in nodes:
            if tree.data(node).node == 'VP':
                vp = None
                va = None
                for cid in tree.ordered_children(node):
                    if tree.data(cid).edge == 'HD' \
                        and tree.data(cid).node.startswith('VA'):
                        va = cid
                    elif tree.data(cid).edge in self.EDGE_LABEL \
                        and tree.data(cid).node == 'VP':
                        vp = cid
                if vp != None and va != None:
                    pa_id = tree.parent(node)
                    to_delete.append(node)
                    tree.remove_edge(pa_id, node)
                    for cid in tree.ordered_children(node):
                        if cid != vp:
                            tree.remove_edge(node, cid)
                            tree.add_edge(vp, cid)
                    tree.data(va).edge = self.AUX_EDGE_LABEL
                    tree.remove_edge(node, vp)
                    tree.add_edge(pa_id, vp)
        for node in to_delete:
            tree.remove_node(node)
            self.countVPErased += 1
        tree.compute_export_numbering()

    def done(self):
        if self.countVPUnderS == 0:
            vpPercentage = 0
        else:
            vpPercentage = 100 * self.countVPUnderS / self.countS
        if self.countNewVPUnderS == 0:
            vpNewPercentage = 0
        else:
            vpNewPercentage = 100 * self.countNewVPUnderS / self.countS
        print str(self.countS) + ' S nodes'
        print 'of which ' + str(self.countVPUnderS) + ' embed a VP (' \
            + str(vpPercentage) + '%)'
        print 'which ' + str(self.countNewVPUnderS) \
            + ' have a newly embedded VP (' + str(vpNewPercentage) \
            + '%)'
        print 'Erased VPs: ' + str(self.countVPErased)
        pass


class T3(Task):

    def __init__(self):
        self.countSPAR = 0

    def do(self, tree):
        for nid in tree.nodes(tree.root):
            main = T3.isRootOfParentheticalSentence(nid, tree)
            if main != None:
                pa = tree.parent(nid)
                if pa == None and tree.data(nid).word == '#0':
                    if tree.exists(parent(main)) == True:
                        tree.remove_edge(parent(main), main)
                    tree.data(main).word = '#0'
                    tree.data(nid).word = '#-1'
                else:
                    tree.remove_edge(tree.parent(main), main)
                    tree.add_edge(pa, main)
                    target = T3.find_target_for_SPAR(nid, tree)
                if target == None:
                    raise RuntimeError('Not possible to re-attach parenthetical sentence'
                            )
                if tree.exists(pa) == True:
                    tree.remove_edge(pa, nid)
                tree.add_edge(target, nid)
                tree.data(main).edge = tree.data(nid).edge
                tree.data(nid).edge = 'SPAR'
                tree.compute_export_numbering()
                self.countSPAR += 1

    @staticmethod
    def isRootOfParentheticalSentence(nid, tree):
        main = None
        loop_break = False
        if tree.data(nid).node == 'S':
            for cid in tree.ordered_children(nid):
                loop_break = False
                if tree.data(cid).node == 'VP' and tree.data(cid).edge \
                    in ['HD', 'OC']:
                    for nidGrandChild in tree.ordered_children(cid):
                        if tree.data(nidGrandChild).node == 'S' \
                            and tree.data(nidGrandChild).edge == 'OC':
                            main = nidGrandChild
                            loop_break = True
                            break
                        if tree.data(nidGrandChild).node == 'AVP' \
                            and tree.data(nidGrandChild).edge == 'MO' \
                            and loop_break == False:
                            for grandGrandChild in \
                                tree.ordered_children(nidGrandChild):
                                if tree.data(grandGrandChild).node \
                                    == 'S' \
                                    and tree.data(grandGrandChild).edge \
                                    == 'RE':
                                    main = grandGrandChild
                                    loop_break = True
                                    break
                        if loop_break == True:
                            break
                if loop_break == True:
                    break
                if tree.data(cid).node == 'AVP' and tree.data(cid).edge \
                    == 'MO':
                    for nidGrandChild in tree.ordered_children(cid):
                        if tree.data(nidGrandChild).node in ['S', 'AVP'
                                ] and tree.data(nidGrandChild).edge \
                            == 'RE':
                            main = nidGrandChild
                            loop_break = True
                            break
                if loop_break == True:
                    break
        elif tree.data(nid).node == 'DL':
            for cid in tree.ordered_children(nid):
                if tree.data(cid).edge == 'RS':
                    main = cid
                    break

        if main != None:
            parenthesisTerms = tree.terminals(nid)
            mainTerm = tree.terminals(main)
            for i in mainTerm:
                paranthesisTerm = \
                    T3.remove_values_from_list(parenthesisTerms, i)
            if min(mainTerm) < min(paranthesisTerm) and max(mainTerm) \
                > max(paranthesisTerm):
                return main
            else:
                return None

    @staticmethod
    def remove_values_from_list(the_list, val):
        if val in the_list:
            the_list.remove(val)
        return the_list

    @staticmethod
    def find_target_for_SPAR(nid, tree):
        lca = []
        term = tree.terminals(nid)
        leftTerm = int(tree.leftmost_terminal(nid)) - 1
        rightTerm = int(max(term)) + 1
        if leftTerm != 0 and tree.exists(rightTerm) == True:

            leftDominating = tree.dominating_nodes(leftTerm, False)
            rightDominating = tree.dominating_nodes(rightTerm, False)
            for lnid in leftDominating:
                for rnid in rightDominating:
                    if lnid == rnid:
                        a = lnid
                        lca.append(a)
            return min(lca)

    def done(self):
        print 'Parenthetical sentence re-attached: ' \
            + str(self.countSPAR) + ' times.'
        pass


class T4(Task):

    def __init__(self):
        self.k = 1
        self.countMO = 0

    def do(self, tree):
        nodes = []
        for nid in tree.nodes(tree.root):
            if nid > 0:
                nodes.append(nid)
        nodes = sorted(nodes)
        nodes.append(0)

        for node in nodes:
            gapDegree = int(len(tree.blocks(node))) - 1
            children = tree.ordered_children(node)
            if gapDegree > self.k:
                if tree.data(node).node == 'VP':
                    i = 0
                    while i < len(children):
                        child = children[i]
                        if T4.isCandidateToReattach(child, tree) \
                            == True:
                            candidates = []
                            candidates.append(child)
                            right = tree.right_sibling(child)
                            while right != -1 \
                                and T4.isCandidateToReattach(right,
                                    tree) == True \
                                and int(max(tree.terminals(child)) + 1) \
                                == int(min(tree.terminals(right))):
                                candidates.append(right)
                                i += 1
                                child = right
                                right = tree.right_sibling(right)
                            path = T4.pathLeftRight(candidates, tree)
                            if 1000 in path:
                                path.remove(1000)
                                path.append(0)
                            if node not in path:
                                for cand in candidates:
                                    self.tryToAttachHigherVerbalNode(cand, node, path, tree)
                                gapDegree = int(len(tree.blocks(node))) \
                                    - 1
                                if gapDegree <= self.k:
                                    break
                        i += 1
        tree.compute_export_numbering()

    def tryToAttachHigherVerbalNode(
        self,
        child,
        node,
        path,
        tree,
        ):
        while tree.data(node).edge == 'CJ':
            node = tree.parent(node)
        while node != -1 and tree.data(node).edge in ['OC', 'HD', 'PD']:
            pa = tree.parent(node)
            if pa in path:
                tree.remove_edge(tree.parent(child), child)
                tree.add_edge(pa, child)
                self.countMO += 1
                break
            if tree.data(pa).node == 'S':
                break
            node = pa
            if tree.data(node).edge == 'CJ':
                node = tree.parent(node)

    @staticmethod
    def isCandidateToReattach(child, tree):
        if tree.data(child).edge == 'MO' \
            or tree.data(child).node.startswith('$'):
            return True
        else:
            return False

    @staticmethod
    def pathLeftRight(candidates, tree):
        termL = tree.terminals(candidates[0])
        termR = tree.terminals(candidates[int(len(candidates) - 1)])
        leftTerm = int(min(termL) - 1)
        rightTerm = int(max(termR) + 1)
        if leftTerm < 1:
            rightTerminal = rightTerm
            union = tree.dominating_nodes(rightTerminal, False)
        elif rightTerm > max(tree.terminals(tree.root)):
            leftTerminal = leftTerm
            union = tree.dominating_nodes(leftTerminal, False)
        else:
            leftTerminal = leftTerm
            rightTerminal = rightTerm
            leftTerminalToRoot = tree.dominating_nodes(leftTerminal,
                    False)
            rightTerminalToRoot = tree.dominating_nodes(rightTerminal,
                    False)
            intersection = [item for item in leftTerminalToRoot if item
                            in rightTerminalToRoot]
            lca = min(intersection)
            union = leftTerminalToRoot
            for item in rightTerminalToRoot:
                if item not in union:
                    union.append(item)
            for item in intersection:
                if item in union:
                    union.remove(item)
            if lca not in union:
                union.append(lca)
        return union

    def done(self):
        print 'Sentential modifier attached higher in its tree: ' \
            + str(self.countMO) + ' times.'
        pass


class T4b(Task):

    def __init__(self):
        self.argEdgeLables = [
            'OC',
            'SB',
            'OA',
            'OA2',
            'OG',
            'OP',
            'PD',
            'DA',
            'SBP',
            'EP',
            'SVP',
            'CD',
            'CJ',
            ]
        self.hdEdgeLabels = ['HD', 'NK', 'PH', 'AUX']
        self.countRemainder = 0
        self.k = 1

    def do(self, tree):

        # bottem up

        nodes = []
        for nid in tree.nodes(tree.root):
            if nid > 0:
                nodes.append(nid)
        nodes = sorted(nodes)
        nodes.append(0)

        for nid in nodes:
            gapDegree = int(len(tree.blocks(nid))) - 1
            if gapDegree <= self.k:
                continue
            maxNodes = self.getMaximalNodes(nid, tree)
            for gap in maxNodes:
                candidate = False
                for maxNode in gap:
                    candidate = self.isCandidateToReattach(maxNode,
                            tree)
                    if candidate == False:
                        break
                if candidate == True:
                    target = self.findTarget(gap, tree)
                    for n in gap:
                        pa = tree.parent(n)
                        tree.remove_edge(pa, n)
                        tree.add_edge(target, n)
                    self.countRemainder += 1
                    gapDegree = int(len(tree.blocks(nid))) - 1
                    if gapDegree <= self.k:
                        break
        tree.compute_export_numbering()

    def getMaximalNodes(self, node, tree):
        blocks = tree.blocks(node)
        termInGap = []
        dominatingNodeInGap = []
        gap = []
        for block in blocks:
            for item in block:
                gap.append(item)
        j = 0
        gapList = []
        while j < int(len(blocks) - 1):
            minBlock = max(blocks[j])
            maxBlock = min(blocks[j + 1])
            gap = []
            i = minBlock + 1
            while i < maxBlock:
                gap.append(i)
                i += 1
            gapList.append(gap)
            j += 1

        for gap in gapList:
            termInGap = []
            dom_list = []
            for term in gap:
                to_remove = []
                parents = tree.dominating_nodes(term, True)
                for parent in parents:
                    if parent == 1000:
                        parent = 0
                    for termParent in tree.terminals(parent):
                        if termParent not in gap and parent \
                            not in to_remove:
                            to_remove.append(parent)
                for item in to_remove:
                    if item == 0:
                        parents.remove(1000)
                    else:
                        parents.remove(item)
                maxDom = parents[len(parents) - 1]
                if maxDom in termInGap:
                    continue
                termInGap.append(maxDom)
            dominatingNodeInGap.append(termInGap)
        return dominatingNodeInGap

    def isCandidateToReattach(self, child, tree):
        if tree.data(child).edge not in self.argEdgeLables \
            and tree.data(child).edge not in self.hdEdgeLabels:
            return True
        else:
            return False

    def findTarget(self, candidates, tree):
        min = 1000
        max = -1
        for n in candidates:
            terms = tree.terminals(n)
            thisMin = terms[0]
            thisMax = terms[int(len(terms) - 1)]
            if thisMin < min:
                min = thisMin
            if thisMax > max:
                max = thisMax
        if max == -1 or min == 1000:
            return None
        leftTerminal = min - 1
        rightTerminal = max + 1
        if tree.exists(leftTerminal) == False:
            return tree.parent(rightTerminal)
        if tree.exists(rightTerminal) == False:
            return tree.parent(leftTerminal)
        lca = 1100
        for leftTerm in tree.dominating_nodes(leftTerminal, True):
            for rightTerm in tree.dominating_nodes(rightTerminal, True):
                if leftTerm == rightTerm and leftTerm < lca:
                    lca = leftTerm
        if lca == 1000:
            lca = 0
        return lca

    def done(self):
        print 'Actions in Remainder: ' + str(self.countRemainder)
        pass


class T4c(Task):

    def __init__(self):
        self.hdEdgeLabels = ['HD', 'NK', 'PH', 'AUX']
        self.countRemainder = 0
        self.k = 1

    def do(self, tree):
        nodes = []
        for nid in tree.nodes(tree.root):
            if nid > 0:
                nodes.append(nid)
        nodes = sorted(nodes)
        nodes.append(0)
        for node in nodes:
            gapDegree = int(len(tree.blocks(node))) - 1
            while gapDegree > self.k:
                self.reduce(node, tree, gapDegree)
                gapDegree = int(len(tree.blocks(node))) - 1
        tree.compute_export_numbering()

    def reduce(
        self,
        node,
        tree,
        gd,
        ):
        orderedTerminals = tree.terminals(tree.root)
        childrenBySpan = self.getOrderedChildrenBySpan(node, tree)
        disturbingChild = None
        for children in childrenBySpan:
            okToReattach = True
            for child in children:
                if self.isHead(child, tree):
                    okToReattach = False
                if self.doesContainOneOfTheGaps(child, node, tree):
                    okToReattach = False
                    disturbingChild = child
                    break
            if okToReattach:
                target = self.findTarget(children, node, tree)
                for child in children:
                    tree.remove_edge(tree.parent(child), child)
                    tree.add_edge(target, child)
                break
        gdNew = int(len(tree.blocks(node))) - 1
        if gdNew < gd:
            return
        if disturbingChild != None:
            gdChild = int(len(tree.blocks(disturbingChild))) - 1
            self.reduce(disturbingChild, tree, gdChild)

    def isHead(self, child, tree):
        if tree.data(child).edge in self.hdEdgeLabels:
            return True
        else:
            return False

    def getOrderedChildrenBySpan(self, node, tree):
        spanlist = []
        alreadyIn = []
        blocks = tree.blocks(node)
        for block in blocks:
            span = []
            for item in block:
                domTerm = tree.dominating_nodes(item, False)
                if min(domTerm) == node:
                    span.append(item)
                else:
                    i = 0
                    for dom in domTerm:
                        if dom == node and domTerm[i - 1] not in span \
                            and domTerm[i - 1] not in alreadyIn:
                            span.append(domTerm[i - 1])
                            alreadyIn.append(domTerm[i - 1])
                        i += 1
            if span not in spanlist and span != []:
                spanlist.append(span)
        return spanlist

    def doesContainOneOfTheGaps(
        self,
        child,
        node,
        tree,
        ):
        if len(tree.blocks(child)) == 1:
            return False
        gapTermListChild = self.calcTermInGaps(child, tree)
        gapTermListNode = self.calcTermInGaps(node, tree)
        inter = gapTermListNode
        for item in inter:
            if item not in gapTermListChild:
                inter.remove(item)
        if len(inter) > 0:
            return True
        return False

    def calcTermInGaps(self, node, tree):
        blocks = tree.blocks(node)
        termInGap = []
        dominatingNodeInGap = []
        gap = []
        for block in blocks:
            for item in block:
                gap.append(item)
        j = 0
        gapList = []
        while j < int(len(blocks) - 1):
            minBlock = max(blocks[j])
            maxBlock = min(blocks[j + 1])
            i = minBlock + 1
            while i < maxBlock:
                gapList.append(i)
                i += 1
            j += 1
        return gapList

    def findTarget(
        self,
        candidates,
        node,
        tree,
        ):
        rightTerms = candidates[len(candidates) - 1]
        leftTerm = min(tree.terminals(candidates[0])) - 1
        rightTerm = max(tree.terminals(rightTerms)) + 1
        a = tree.ordered_children(node)
        if leftTerm < 1 or tree.ordered_children(node)[0] \
            == candidates[0]:
            return tree.parent(rightTerm)
        if tree.exists(rightTerm) == False or a[len(a) - 1] \
            == candidates[len(candidates) - 1]:
            return tree.parent(leftTerm)
        lca = 1100
        for left in tree.dominating_nodes(leftTerm, False):
            for right in tree.dominating_nodes(rightTerm, False):
                if left == right and left < lca:
                    lca = left
        if lca == 1000:
            lca = 0
        return lca

    def done(self):
        pass


################################################################
#
# CONTROL STUFF
#
################################################################

def usage():
    print """
Reduce block degre of NeGra to two.

    Syntax: blockdegreetwo.py -i infile -o outfile

where infile is NeGra or TIGER in export format and outfile 
is the desired output file.
    """


def main():
    try:
        (opts, _) = getopt.getopt(sys.argv[1:], 'hi:o:', ['help',
                                  'input=', 'output='])
    except getopt.GetoptError, err:
        sys.stderr.write(str(err) + '\n')
        usage()
        sys.exit(1)
    inpf = None
    outpf = None
    for (o, a) in opts:
        if o in ('-h', '--help'):
            usage()
            sys.exit()
        elif o in ('-i', '--input'):
            inpf = a
        elif o in ('-o', '--output'):
            outpf = a
        else:
            assert False, 'unhandled option'
    assert not (inpf == None or outpf == None), \
        'you must provide both an input file and an output file'
    assert os.path.exists(inpf), 'input file does not exist'
    inp = codecs.open(inpf, mode='rb', encoding='iso-8859-1')
    outp = codecs.open(outpf, mode='w', encoding='utf-8')
    tasks = [Progress(1000), T2(), T1(), T3(), T4(), T4b(), T4c(), \
                 ExportWriterTask(outp, True)]

    ExportTreeReader().parse(inp, tasks)


if __name__ == '__main__':
    main()
